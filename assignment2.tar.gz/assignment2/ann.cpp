#include <iostream>
#include <math.h>
#include <iomanip>
#include "ann.h"

using namespace std;

/*
  The nueral network is made up of a vector of Node vectors, where each node has a vector of weights
  to access a given layer, use network[x] where x is the layer. Accessing each value for the specified
  layer can be achieved with network[x][y] which will evaluate into a Node. Node values can be accessed
  by network[x][y].weights[z] which will evaluate into a long double
*/

static long double digits[10][10] = { {0.1, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.1, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.1, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.1, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.1, 0.9, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.9, 0.1, 0.9, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.1, 0.9, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.1, 0.9, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.1, 0.9},
                                   {0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.1} };


void ANN::train(vector<long double> inputs, int label){
  cout << showpoint << fixed << setprecision(12);
  //feed forward start

  //set the A values for the input layer
  cout << "Setting A values for the input layer " << endl;
  for(int i = 0; i < network[0].size(); i++){
    network[0][i].aValue = inputs[i];
    cout << "layer: 0, node: " << i << " set to: " << inputs[i] << endl;
  }

  //for the rest of the layers, calculate A and INj

  //for all of the layers, starting with 1
  for(int i = 1; i < network.size(); i++){
    //for all of the nodes in the layer
    for(int j = 0; j < network[i].size(); j++){
      cout << "layer: " << i << " node: " << j;
      long double inj = 0;
      //for all of the previous layer's nodes
      for(int k = 0; k < network[i-1].size(); k++){
        inj += network[i-1][k].aValue * network[i-1][k].weights[j];
      }
      inj += network[i][j].dummy;
      cout << " inj: " << inj;
      //SAF
      network[i][j].aValue = (long double)1/((long double)1+expl(-inj));
      cout << " A value: " << network[i][j].aValue << endl;
    }
  }

  //feed forward finish


  //back propagate start

  //calcualte error
  //calculate output layer ERROR


  int output = network.size()-1;

  //for all of the output layer nodes:
  cout << "Calculating delta values " << endl;
  for(int i = 0; i < network[output].size(); i++){
    //the delta value for an output node is Aj*(1-Aj)(Yj-Aj)
    network[output][i].delta = network[output][i].aValue*((long double)1-network[output][i].aValue)*(digits[label][i]-network[output][i].aValue);
    cout << "layer: " << output << " node: " << i << " delta: " << network[output][i].delta << endl;
  }
  //calculate other layers' ERROR
  for(int i = network.size()-2; i > 0; i--){
    for(int j = network[i].size()-1; j >= 0; j--){
        //Esum is the sum of the deltas from the next layer * their respective weights to the node
        long double Esum  = 0;
        for(int k = 0; k < network[i+1].size(); k++){
          Esum += network[i+1][k].delta * network[i][j].weights[k];
        }
        network[i][j].delta = network[i][j].aValue*((long double)1-network[i][j].aValue)*Esum;
          cout << "layer: " << i << " node: " << j << " delta: " << network[i][j].delta << endl;
    }
  }


  //adjust the weights
  cout << "Adjusting weights" << endl;
  //for a given layer, i
  for(int i = 0; i < network.size() - 1; i++){
    //for a given node, j
    for(int j = 0; j < network[i].size(); j++){
      //update the dummy weight
      network[i][j].dummy += network[i][j].aValue * (long double)0.01 * network[i][j].delta;
      //for a given weight, k
      for(int k = 0; k < network[i][j].weights.size(); k++){
        //the weight for a specific edge is oldWeight + .01 * aValue * destination node's delta
        network[i][j].weights[k] += ((long double)0.01*(network[i][j].aValue)*(network[i][k].delta));
        cout << "layer: " << i << " weight from " << j << " to " << k << " : " << network[i][j].weights[k]  << endl;
      }
    }
  }
}

void ANN::print(){
  cout << showpoint << fixed << setprecision(12);
  for(int x = 0; x < network[0].size(); x++){
    for(int k = 0; k < network[x][0].weights.size(); k++){
      cout << network[x][0].weights[k] << " ";
    }
    cout << endl;
  }
}
